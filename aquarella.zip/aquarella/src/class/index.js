"use strict";

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
var DataBase = /*#__PURE__*/_createClass(function DataBase(db, message) {
  var _this = this;
  _classCallCheck(this, DataBase);
  _defineProperty(this, "user", function () {
    return new _this.User(_this.DataBase, _this.message);
  });
  _defineProperty(this, "card", function () {
    return new _this.Card(_this.DataBase, _this.message);
  });
  _defineProperty(this, "level", function () {
    return new _this.Level(_this.DataBase, _this.message);
  });
  _defineProperty(this, "gift", function () {
    return new _this.Gift(_this.DataBase.Gift);
  });
  _defineProperty(this, "store", function () {
    return new _this.Store(_this.DataBase);
  });
  _defineProperty(this, "mix", function () {
    return new _this.Mix(_this.DataBase);
  });
  this.DataBase = db;
  this.message = message;
  this.User = require('./user');
  this.Card = require('./card');
  this.Level = require('./level');
  this.Gift = require('./gift');
  this.Store = require('./store');
  this.Mix = require('./mix');
});
module.exports = DataBase;