const request = require('request-promise')
const fs = require('fs')
const randexp = require('randexp')
const { Agent } = require('https')

interface ClientCredentials {
  cert: string
  client_id: string
  client_secret: string
  key: string
}

interface ApiOptions {
  body?: string
  url: string
  method: 'POST' | 'PUT' | 'GET' | 'PATCH'
}

interface BillingData {
  calendario: { expiracao: number }
  devedor?: {
    cpf: string
    nome: string
  }
  valor: {
    original: string
  }
  solicitacaoPagador?: string
  infoAdicionais?: string[]
}

interface loc {
  id: number
  location: string
  tipoCob: string
  criacao: string
}

interface BillingResponse extends BillingData {
  calendario: {
    expiracao: number
    criacao: string
  }
  txid: string
  revisao: number
  loc: loc
  location: string
  status: 'ATIVA' | 'CONCLUIDA' | 'REMOVIDA_PELO_USUARIO_RECEBEDOR'
  chave: string
}

class GerencianetPix implements ClientCredentials {
  readonly cert
  readonly client_id
  readonly client_secret
  readonly key

  constructor(credentials: ClientCredentials) {
    this.cert = credentials.cert
    this.client_id = credentials.client_id
    this.client_secret = credentials.client_secret
    this.key = credentials.key
  }

  async api(options: ApiOptions): Promise<BillingResponse | string> {
    const certBuffer = fs.readFileSync(`${this.cert}`)

    const body = JSON.stringify({
      grant_type: 'client_credentials'
    })

    const credentialsToken = Buffer.from(
      `${this.client_id}:${this.client_secret}`
    ).toString('base64')

    const agent = new Agent({
      pfx: certBuffer,
      passphrase: '',
      keepAlive: true,
      maxSockets: 256
    })

    const config = {
      method: 'POST',
      url: 'https://api-pix.gerencianet.com.br/oauth/token',
      headers: {
        Authorization: `Basic ${credentialsToken}`,
        'Content-Type': 'application/json'
      },
      timeout: 15000,
      agent: agent,
      body: body,
      pool: { maxSockets: 1024 }
    }

    const response = JSON.parse(
      await request(config).catch((error: any) =>
        JSON.stringify(error?.error ?? { ...error })
      )
    )

    const bearer: string = response?.access_token

    if (!bearer) return response

    return request({
      headers: {
        Authorization: `Bearer ${bearer}`,
        'Content-Type': 'application/json'
      },
      timeout: config.timeout,
      agent: agent,
      pool: config.pool,
      ...options
    }).catch((error: Error) => error?.message ?? `${error}`)
  }

  createPixBilling(options: BillingData) {
    const txId = new randexp(/^[a-zA-Z0-9]{26,35}$/).gen().toUpperCase()

    const body = {
      ...options,
      chave: this.key
    }

    return this.api({
      method: 'PUT' as 'PUT',
      url: `https://api-pix.gerencianet.com.br/v2/cob/${txId}`,
      body: JSON.stringify(body)
    })
  }

  genQrCode({ loc }: { loc: loc }) {
    const qrCodeId = loc.id

    return this.api({
      method: 'GET' as 'GET',
      url: `https://api-pix.gerencianet.com.br/v2/loc/${qrCodeId}/qrcode`
    })
  }

  checkBilling({ txid }: { txid: BillingResponse }) {
    return this.api({
      method: 'GET' as 'GET',
      url: `https://api-pix.gerencianet.com.br/v2/cob/${txid}`
    })
  }

  reviseBilling({ txid }: { txid: BillingResponse }, config: object = {}) {
    return this.api({
      method: 'PATCH' as 'PATCH',
      url: `https://api-pix.gerencianet.com.br/v2/cob/${txid}`,
      body: JSON.stringify(config)
    })
  }
}

const gerencianet = new GerencianetPix({
  cert: __dirname + '/../../certs/producao-313272-gcert.p12',
  client_id: 'Client_Id_55d490eae7b7a865f2bb1c97812f16b65130d273',
  client_secret: 'Client_Secret_fc006f13ca59b13d8d9c742364199621d6a2bb02',
  key: 'd25f4a3f-e2eb-481c-8589-39e62e0abf2b'
})

;(async () => {
  const result = await gerencianet.createPixBilling({
    calendario: {
      expiracao: 3600
    },
    devedor: {
      cpf: '12345678909',
      nome: 'Francisco da Silva'
    },
    valor: {
      original: '123.45'
    }
  })

  const resp = JSON.parse(result as string)

  console.log(await gerencianet.genQrCode(resp))
})()

//export default GerencianetPix
