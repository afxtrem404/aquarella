'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
  lara: {
    required: true,
    type: String
  }
});
module.exports = schema;