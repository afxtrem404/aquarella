'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
  name: {
    required: true,
    type: String
  },
  id: {
    type: Number,
    unique: true,
    required: true
  },
  historic: {
    type: Array,
    required: true
  },
  credits: {
    type: Number,
    trim: true,
    required: true
  },
  restrict: {
    type: Boolean,
    required: true
  },
  current_transactions: {
    type: Number,
    required: true
  },
  admin: {
    type: Boolean,
    required: true
  },
  shopping: {
    credits: {
      type: Number,
      required: true
    },
    cards: {
      type: Number,
      required: true
    },
    gifts: {
      type: Number,
      required: true
    }
  },
  in_purchase: {
    type: Boolean,
    required: true
  }
}, {
  timestamps: true
});
module.exports = schema;